let perguntas = [
  {
    pergunta: "Qual é a principal característica do campo?",
    opcoes: [
      "Mais áreas verdes",
      "Mais construções",
      "Maior quantidade de transporte público",
      "Muita tecnologia",
    ],
    resposta: 0, // Índice da resposta correta
  },
  {
    pergunta: "O que é mais comum nas cidades grandes?",
    opcoes: ["Trânsito intenso", "Espaços amplos", "Silêncio", "Ar puro"],
    resposta: 0,
  },
  {
    pergunta: "Qual a vantagem principal de viver no campo?",
    opcoes: [
      "Tradição e contato com a natureza",
      "Muitas opções de lazer",
      "Muita tecnologia",
      "Acessibilidade",
    ],
    resposta: 0,
  },
  {
    pergunta: "O que caracteriza as grandes cidades?",
    opcoes: [
      "Muita agitação e diversidade cultural",
      "Calmaria e espaços amplos",
      "Paz e tranquilidade",
      "Mais espaços para agricultura",
    ],
    resposta: 0,
  },
];

let perguntaAtual = 0;
let respostaSelecionada = -1;
let quizFinalizado = false;

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
}

function draw() {
  background(255);

  // Mostrar a pergunta
  textSize(24);
  text(perguntas[perguntaAtual].pergunta, width / 2, 50);

  // Mostrar as opções
  textSize(18);
  for (let i = 0; i < perguntas[perguntaAtual].opcoes.length; i++) {
    let y = 150 + i * 40;
    text(perguntas[perguntaAtual].opcoes[i], width / 2, y);
  }

  // Verificação de resposta
  if (respostaSelecionada !== -1) {
    if (respostaSelecionada === perguntas[perguntaAtual].resposta) {
      fill(0, 255, 0); // Resposta correta
    } else {
      fill(255, 0, 0); // Resposta errada
    }
    ellipse(width / 2, 350, 50, 50);
    fill(0);
    textSize(16);
    text(
      respostaSelecionada === perguntas[perguntaAtual].resposta
        ? "Correto!"
        : "Errado!",
      width / 2,
      350
    );
    noLoop(); // Pausar o quiz por enquanto até o próximo clique
  }
}

function mousePressed() {
  if (quizFinalizado) {
    return;
  }

  for (let i = 0; i < perguntas[perguntaAtual].opcoes.length; i++) {
    let y = 150 + i * 40;
    if (mouseY > y - 20 && mouseY < y + 20) {
      respostaSelecionada = i;
      if (i === perguntas[perguntaAtual].resposta) {
        perguntaAtual++;
        if (perguntaAtual >= perguntas.length) {
          quizFinalizado = true;
          setTimeout(() => {
            alert("Parabéns! Você terminou o quiz!");
          }, 500);
        }
      }
      loop(); // Continuar o quiz
      break;
    }
  }
}
